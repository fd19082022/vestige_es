<?php
// make_hash.php
// Cambia 'admin123' por la contraseña que tú quieras usar
echo password_hash('admin123', PASSWORD_DEFAULT);
