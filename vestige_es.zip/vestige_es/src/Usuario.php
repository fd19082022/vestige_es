<?php
/**
 * src/Usuario.php
 * Gestión de usuarios - CORREGIDA
 * 
 * Cambios:
 * - Usa DB::conn()
 * - Mejor validación
 * - Rol por defecto correcto
 */

require_once __DIR__ . '/DB.php';
require_once __DIR__ . '/Helper.php';
require_once __DIR__ . '/../config/loader.php';

class Usuario {

    /**
     * Crear nuevo usuario
     * 
     * @param array $data
     * @return int ID del usuario creado
     * @throws Exception
     */
    public static function crear(array $data): int {
        $nombre = trim($data['nombre'] ?? '');
        $correo = strtolower(trim($data['correo'] ?? ''));
        $password = trim($data['password'] ?? '');
        $telefono = trim($data['telefono'] ?? '');

        // Validar nombre
        if (strlen($nombre) < 3 || strlen($nombre) > 100) {
            throw new Exception("El nombre debe tener entre 3 y 100 caracteres");
        }

        // Validar email
        if (!Helper::validateEmail($correo)) {
            throw new Exception("Email inválido");
        }

        // Validar contraseña
        if (strlen($password) < 6 || strlen($password) > 255) {
            throw new Exception("La contraseña debe tener entre 6 y 255 caracteres");
        }

        try {
            $pdo = DB::conn();

            // Verificar que email no existe
            $stmt = $pdo->prepare("SELECT id FROM usuarios WHERE LOWER(correo) = ? LIMIT 1");
            $stmt->execute([$correo]);
            if ($stmt->fetch()) {
                throw new Exception("El email ya está registrado");
            }

            // Obtener rol comprador (por defecto)
            $stmt = $pdo->prepare("SELECT id FROM roles WHERE id = ? LIMIT 1");
            $stmt->execute([ROLE_COMPRADOR]);
            $rolRow = $stmt->fetch();

            if (!$rolRow) {
                throw new Exception("Rol por defecto no existe en la base de datos");
            }

            // Crear usuario
            $password_hash = password_hash($password, PASSWORD_BCRYPT, ['cost' => 12]);

            $stmt = $pdo->prepare("
                INSERT INTO usuarios 
                (nombre, apellido, correo, password_hash, telefono, rol_id, estado)
                VALUES (?, ?, ?, ?, ?, ?, 'activo')
            ");

            $stmt->execute([
                $nombre,
                '', // apellido vacío (puede editarse después)
                $correo,
                $password_hash,
                !empty($telefono) ? $telefono : null,
                ROLE_COMPRADOR
            ]);

            return (int)$pdo->lastInsertId();

        } catch (PDOException $e) {
            if (strpos($e->getMessage(), 'Duplicate') !== false) {
                throw new Exception("El email ya está registrado");
            }
            throw new Exception("Error al crear usuario: " . $e->getMessage());
        }
    }

    /**
     * Obtener usuario por ID
     * 
     * @param int $id
     * @return array|null
     */
    public static function obtenerPorId(int $id): ?array {
        if ($id <= 0) {
            return null;
        }

        try {
            $pdo = DB::conn();

            $stmt = $pdo->prepare("
                SELECT 
                    u.id,
                    u.nombre,
                    u.apellido,
                    u.correo,
                    u.telefono,
                    u.rol_id,
                    u.estado,
                    u.creado_en,
                    u.actualizado_en,
                    r.nombre AS rol_nombre
                FROM usuarios u
                LEFT JOIN roles r ON r.id = u.rol_id
                WHERE u.id = ?
                LIMIT 1
            ");
            $stmt->execute([$id]);

            return $stmt->fetch(PDO::FETCH_ASSOC) ?: null;

        } catch (Exception $e) {
            return null;
        }
    }

    /**
     * Obtener usuario por email
     * 
     * @param string $correo
     * @return array|null
     */
    public static function obtenerPorEmail(string $correo): ?array {
        $correo = strtolower(trim($correo));

        if (!Helper::validateEmail($correo)) {
            return null;
        }

        try {
            $pdo = DB::conn();

            $stmt = $pdo->prepare("
                SELECT u.*, r.nombre AS rol_nombre
                FROM usuarios u
                LEFT JOIN roles r ON r.id = u.rol_id
                WHERE LOWER(u.correo) = ?
                LIMIT 1
            ");
            $stmt->execute([$correo]);

            return $stmt->fetch(PDO::FETCH_ASSOC) ?: null;

        } catch (Exception $e) {
            return null;
        }
    }

    /**
     * Actualizar usuario
     * 
     * @param int $id
     * @param array $data
     * @return bool
     */
    public static function actualizar(int $id, array $data): bool {
        if ($id <= 0) {
            return false;
        }

        try {
            $pdo = DB::conn();

            $campos = [];
            $valores = [];

            // Nombre
            if (isset($data['nombre'])) {
                $nombre = trim($data['nombre']);
                if (strlen($nombre) < 3 || strlen($nombre) > 100) {
                    return false;
                }
                $campos[] = "nombre = ?";
                $valores[] = $nombre;
            }

            // Apellido
            if (isset($data['apellido'])) {
                $campos[] = "apellido = ?";
                $valores[] = trim($data['apellido']);
            }

            // Teléfono
            if (isset($data['telefono'])) {
                $telefono = trim($data['telefono']);
                $campos[] = "telefono = ?";
                $valores[] = !empty($telefono) ? $telefono : null;
            }

            // Contraseña
            if (isset($data['password'])) {
                $password = trim($data['password']);
                if (strlen($password) < 6 || strlen($password) > 255) {
                    return false;
                }
                $campos[] = "password_hash = ?";
                $valores[] = password_hash($password, PASSWORD_BCRYPT, ['cost' => 12]);
            }

            // Rol (solo admin)
            if (isset($data['rol_id'])) {
                $rol_id = (int)$data['rol_id'];
                if ($rol_id > 0) {
                    $stmt = $pdo->prepare("SELECT id FROM roles WHERE id = ? LIMIT 1");
                    $stmt->execute([$rol_id]);
                    if ($stmt->fetch()) {
                        $campos[] = "rol_id = ?";
                        $valores[] = $rol_id;
                    }
                }
            }

            // Estado (solo admin)
            if (isset($data['estado'])) {
                $estado = strtolower(trim($data['estado']));
                if (in_array($estado, ['activo', 'suspendido', 'eliminado'], true)) {
                    $campos[] = "estado = ?";
                    $valores[] = $estado;
                }
            }

            if (empty($campos)) {
                return false;
            }

            $valores[] = $id;
            $sql = "UPDATE usuarios SET " . implode(", ", $campos) . " WHERE id = ?";

            $stmt = $pdo->prepare($sql);
            return $stmt->execute($valores);

        } catch (Exception $e) {
            return false;
        }
    }

    /**
     * Cambiar estado de usuario
     * 
     * @param int $id
     * @param string $estado
     * @return bool
     */
    public static function cambiarEstado(int $id, string $estado): bool {
        return self::actualizar($id, ['estado' => $estado]);
    }

    /**
     * Eliminar usuario (marcar como eliminado)
     * 
     * @param int $id
     * @return bool
     */
    public static function eliminar(int $id): bool {
        return self::cambiarEstado($id, 'eliminado');
    }

    /**
     * Verificar si usuario existe
     * 
     * @param int $id
     * @return bool
     */
    public static function existe(int $id): bool {
        return self::obtenerPorId($id) !== null;
    }
}
