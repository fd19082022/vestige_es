<?php

?>
    </main>
    <footer class="pie">
        <div class="contenedor pie__contenido">
            <p>© <?= date('Y') ?> Vestige — Venta de ropa en Bolivia</p>
            <p><a href="#">Términos</a> · <a href="#">Privacidad</a></p>
        </div>
    </footer>
    <script src="<?= BASE_URL ?>/assets/js/app.js"></script>
</body>
</html>