<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title><?= $titulo ?? 'Vestige - Marketplace de Ropa' ?></title>
  <link rel="stylesheet" href="<?= BASE_URL ?>/assets/css/styles.css">
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@400;600;700;800&display=swap" rel="stylesheet">
  <style>
    .btn-admin {
      background: linear-gradient(135deg, #8E3D56 0%, #AB4E6A 100%);
      color: white !important;
      padding: 0.6rem 1.2rem;
      border-radius: 0.5rem;
      font-weight: 600;
      border: 2px solid transparent;
      transition: all 0.3s ease;
      box-shadow: 0 2px 8px rgba(142, 61, 86, 0.3);
    }
    .btn-admin:hover {
      transform: translateY(-2px);
      box-shadow: 0 4px 12px rgba(142, 61, 86, 0.5);
      border-color: rgba(255, 255, 255, 0.3);
    }
    .nav-mensajes {
      position: relative;
      display: inline-block;
    }
    .badge-notif {
      position: absolute;
      top: -8px;
      right: -8px;
      background: #ef4444;
      color: white;
      font-size: 11px;
      font-weight: 700;
      padding: 2px 6px;
      border-radius: 10px;
      min-width: 18px;
      text-align: center;
      box-shadow: 0 2px 8px rgba(239, 68, 68, 0.5);
      animation: pulse 2s ease infinite;
    }
    @keyframes pulse {
      0%, 100% { transform: scale(1); }
      50% { transform: scale(1.1); }
    }
  </style>
</head>
<body>

<header class="encabezado">
  <div class="contenedor encabezado__contenido">
    <a href="<?= BASE_URL ?>/index.php" class="logo">
      <img src="<?= BASE_URL ?>/assets/imgs/logo.png" alt="Vestige" onerror="this.style.display='none'">
      <span>Vestige</span>
    </a>
    
    <nav class="navegacion">
      <a href="<?= BASE_URL ?>/explorar.php">Explorar</a>
      
      <?php if (Helper::esta_logueado()): ?>
        <?php
        // Obtener mensajes no leídos
        $pdo = DB::conn();
        $st_notif = $pdo->prepare("SELECT COUNT(*) FROM mensajes WHERE destinatario_id = ? AND leido = 0");
        $st_notif->execute([Helper::getCurrentUserId()]);
        $mensajes_no_leidos = (int)$st_notif->fetchColumn();
        ?>
        
        <a href="<?= BASE_URL ?>/publicacion_nueva.php">Publicar</a>
        <a href="<?= BASE_URL ?>/mis_publicaciones.php">Mis Publicaciones</a>
        <a href="<?= BASE_URL ?>/mis_ofertas.php">Mis Ofertas</a>
        <a href="<?= BASE_URL ?>/ofertas_recibidas.php">Ofertas Recibidas</a>
        <a href="<?= BASE_URL ?>/favoritos.php">Favoritos</a>
        
        <span class="nav-mensajes">
          <a href="<?= BASE_URL ?>/mis_conversaciones.php">💬 Mensajes</a>
          <?php if ($mensajes_no_leidos > 0): ?>
            <span class="badge-notif"><?= $mensajes_no_leidos ?></span>
          <?php endif; ?>
        </span>
        
        <a href="<?= BASE_URL ?>/perfil.php">Mi Perfil</a>
        
        <?php if (Helper::es_admin()): ?>
          <a href="<?= BASE_URL ?>/admin/index.php" class="btn-admin">
            🛡️ Panel Admin
          </a>
        <?php endif; ?>
        
        <a href="<?= BASE_URL ?>/logout.php" class="btn-salir">Salir</a>
      <?php else: ?>
        <a href="<?= BASE_URL ?>/login.php" class="btn">Iniciar sesión</a>
        <a href="<?= BASE_URL ?>/registro.php" class="btn-primario">Registrarse</a>
      <?php endif; ?>
    </nav>
  </div>
</header>